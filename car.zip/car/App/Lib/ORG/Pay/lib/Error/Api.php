<?php

namespace Pingpp\Error;

class Api extends Base
{
}
