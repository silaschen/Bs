<?php
/**
	##违章查询 车辆管理 违章处理 违章提醒
	##
**/
class IllegalAction extends CommonAction{




	/**
		###########################后台######################################
	**/
	#车辆违章列表#
	public function illegallist(){
			$this->IsAdm(true);
			if (IS_GET) {
				$this->title = "违章车订单列表";
				$this->eq = "会员管理";
				$p = I("p",1);
				$id = I("id");
				$word = I("word");
				$start = I("start");
				$start=I('start'); //开始时间
				$end=I('end'); //结束时间
				$map = array();
				if($start && $end){//开始和结束时间全部存在
					$map["addtime"] = array("BETWEEN",array($start,$end));//find the data between the begin time and the edn time
				}else if($start){
				//only the begin  time
					$map['addtime']=array("EGT",$start);

				}else if($end) {

					$map['addtime'] = array("ELT",$end);//查询终结时间之前的数据
				}
				if ($word)$map['tel'] = array("like","%".$word."%");

				$map['status'] = array('egt',0);
				if ($stat) {
					$map['status'] = $stat;
				}


				$model = M("illegal_carlist");
				import('@.ORG.Util.Page');// 导入分页类
				$list = $model->where($map)->page($p.',10')->order("addtime desc")->select();
				$count	= $model->where($map)->count();// 查询满足要求的总记录数
				$page 	= new Page($count,10);// 实例化分页类 传入总记录数和每页显示的记录数
				$page->setConfig('theme','%upPage%  %linkPage%  %downPage%');
				$page->rollPage = 5 ;
				$show	= $page->show();// 分页显示输出
				$this->assign('page',$show);// 赋值分页输出
				//分页跳转的时候保证查询条件
				foreach($map as $key=>$val) {
					$page->parameter   .=   "$key=".urlencode($val).'&';
				}
				$this->assign('list',$list);
				$this->display();

			}else{




			}





	}


}