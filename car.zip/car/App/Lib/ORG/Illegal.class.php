<?php
/**
##车辆违章 数据接口
	2017-03-06
**/
define('API_TYPE', 1); //数据接口类型 1免费接口 2交管接口
class Illegal{
	#查询车辆违章#
	public function CarIll($cphm,$type='02',$vin='',$eng='',$area=''){
		
	}

}