<?php 
/**
* ##商品管理

*/
class ProductAction extends CommonAction
{
	




	/**
	#################################################################################################################################################
			#####################后台##################################
	**/
	#商品管理#
	public function plist(){
		$this->IsAdm(true);
		if(IS_GET){
			$this->title = '商品列表';
			$this->eq = '商品管理';
			$p = I('p',1);
			$id = I("id");
			$word = I('word');
			$stat = I("stat");
			$show = I("show");
			$map = array();
			if ($id) $map['a.id'] = $id;
			if($word) $map['a.title|b.name'] = array('like','%'.$word.'%');
			$map['a.status'] = array('egt',0);
			if ($stat == 1) {
				$map['a.status'] = $stat;
			}elseif($stat == 3){
				$map['a.status'] = array("egt",0);
			}elseif($stat == 2){

				$map['a.status'] = 0;
			}

			if ($show) {
				if ($show == 3) {
					$map['a.show'] = array('egt',0);
				}else{

					$map['a.show'] = $show;
				}
			}
			$model = M('shop_item');
			import('@.ORG.Util.Page');// 导入分页类
			$list = $model->alias("a")
			->join("bingo_shop_list b ON a.sid=b.id")
			->where($map)
			->order('a.id desc')
			->field("a.id,a.sid,a.title,a.c1,a.c2,a.price,a.addtime,a.show,a.status,a.cover,b.name as shopname")
			->page($p.',10')
			->select();
			foreach ($list as $key => $value) {
				
				$list[$key]['c1n'] = M("shop_cate")->where(array('id'=>$value['c1']))->getField("name");
				if ($value['c2'] > 0) {
					$list[$key]['c2n'] =  M("shop_cate")->where(array('id'=>$value['c2']))->getField("name");
				}
			}

			$this->assign('list',$list);// 赋值数据集
			$count	= $model->alias("a")
			->join("bingo_shop_list b ON a.sid=b.id")
			->where($map)->count();// 查询满足要求的总记录数
			$this->total = $count;
			$page 	= new Page($count,10);// 实例化分页类 传入总记录数和每页显示的记录数
			$page->setConfig('theme','%upPage%  %linkPage%  %downPage%');
			$page->rollPage = 5 ;
			$show	= $page->show();// 分页显示输出
			$this->assign('page',$show);// 赋值分页输出
			//分页跳转的时候保证查询条件
			foreach($map as $key=>$val) {
				$page->parameter   .=   "$key=".urlencode($val).'&';
			}

			$this->display();
		}else{
			$id = I('id');
			$t = I('t');
			if ($t == 1 || $t == 2) {
				$r = M('shop_item')->where(array('id'=>$id))->setField('show',$t);
			}else{

				$r = M("shop_item")->where(array('id'=>$id))->setField("status",$t);
			}
			
			json('操作成功!',1);
		}
	}


	#编辑商品#
	public function editpro(){
		$this->IsAdm(true);
		if(IS_GET){
			if (IS_AJAX) {
				$c1 = I("c1");
				$cat = M("shop_cate")->where(array('pid'=>$c1))->select();
				if ($cat) {
					$this->ajaxReturn($cat);
				}
			}
			$this->title = '修改商品';
			$this->eq = '商品管理';
			$id = I('id');
			if($id > 0){
				$info = M('shop_item')->where(array('id'=>$id))->find();
				$this->assign('info',$info);
			}
			//get the cates
			$cates = M("shop_cate")->where(array('pid'=>0))->order("id desc")->select();
			$this->assign("cates",$cates);
			$this->display();
		}else{
			$data = I('post.');

			if($data['id'] > 0){
				$r = M('shop_item')->where(array('id'=>$data['id']))->save($data);
			}else{
				// 新增
				$data['addtime'] = NOW_TIME;
				$data['sid'] = $_SESSION['shop_uid'];

				$r = M('shop_item')->add($data);
			}
			if($r){
				json("保存成功",1);
			}else{
				json("保存失败");
			}
		}
	}



	#商品分类管理#
	public function catelist(){
		$this->IsAdm(true);
		//处理页面访问请求
		if(IS_GET){
			$this->title = '分类管理';
			$this->eq = '商品管理';
			$word = I('word');
			$p = I('p',1);
			$word = I('word');
			$map = array();
			if($word){
				$map['name'] = array('like','%'.$word.'%');
			}else{

				$map['pid'] = 0;
			}
			
			$map['status'] = array('egt',0);
			$model = M('shop_cate');
			import('@.ORG.Util.Page');// 导入分页类
			$list = $model->where($map)->order('addtime desc')->page($p.',10')->select();

			foreach ($list as $key => $value) {
				$list[$key]['son'] = $model->where(array('pid'=>$value['id']))->order('addtime desc')->select();
			}

			$this->assign('list',$list);// 赋值数据集			
			$count	= $model->where($map)->count();// 查询满足要求的总记录数
			$this->total = $count;
			$page 	= new Page($count,10);// 实例化分页类 传入总记录数和每页显示的记录数
			$page->setConfig('theme','%upPage%  %linkPage%  %downPage%');
			$page->rollPage = 5 ;
			$show	= $page->show();// 分页显示输出
			$this->assign('page',$show);// 赋值分页输出
			//分页跳转的时候保证查询条件
			foreach($map as $key=>$val) {
				$page->parameter   .=   "$key=".urlencode($val).'&';
			}	
		 	$this->display();
		}else{
			$id = I('post.id');
			$status = I('post.t');
			$model = M('shop_cate');
			if($id>0){
				if($status == -1){
					
					$caterow = $model->where(array('pid'=>$id))->count();
					if($caterow>0) json("该分类下存在子分类，请先删除子分类！");
					$r = $model->where(array('id'=>$id))->delete();
				}else{
					$r = $model->where(array('id|pid'=>$id))->setField('status',$status);
				}
				if($r) json('操作成功！',1);
				json('操作失败！');
			}	
		}	
	}
	#添加修改分类#
    public function addcate(){
		$this->IsAdm(true);
		if(IS_GET){
			$this->title = '添加/编辑商品分类';
			$this->eq = '商品管理';
			$id = I('get.id');
			$model = M('shop_cate');
			$data['cates']=M('shop_cate')->where(array('pid'=>0))->select();
			if($id>0){
				$data['info'] = M('shop_cate')->where(array('id'=>$id))->find();
				$data['info']['parname']=M('shop_cate')->where(array('id'=>$data['info']['pid']))->getField('name');
			}
		    $this->assign($data);
			$this->display();
		}else{
			$data = I('post.');
			if($data['id'] > 0){
				$r = M('shop_cate')->where(array('id'=>$data['id']))->save($data);
			}else{
				// 新增
				$data['addtime'] = NOW_TIME;
				$r = M('shop_cate')->add($data);
			}
			if($r){
				json("保存成功",1);
			}else{
				json('保存失败!');
			}
		}
	}

	#审核商品#
	public function Check(){
		$this->IsAdm(true);
		$id = I("id");
		$price = I("jsprice");
		$st = I("sta");
		$r = M("shop_item")->where(array('id'=>$id))->setField(array('js'=>$price,'status'=>$st));

		if ($r) {
			json("操作成功",1);
		}
	}



}







 ?>