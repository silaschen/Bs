<?php
/**
	##车险销售
	##
	##YangLin 2016/10/11
**/
class InsuranceAction extends CommonAction{
	#投保页面#
	public function index(){
		if(IS_GET){
			$this->IsUser(true);
			if(IS_AJAX){
				$cphm = 'A'.I('cphm');
				import("@.ORG.Traff");
				$Traff = new Traff();
				$r = $Traff->CarInfo($cphm,'02');
				preg_match_all("/\{.*?\}/is", $r, $matches);
				$rs = json_decode($matches[0][1],true);
				if(!$rs){
					json('对不起！暂时查询不到该车辆信息!');
				}else{
					$data = array();
					$data['model'] = $rs['clpp1'];
					$data['register_date'] = mb_substr($rs['ccdjrq'],0,10,'utf8');
					if($rs['hdzk'] < 6){
						$data['limit'] = 1;
					}else{
						$data['limit'] = 2;
					}
					if($rs['pl'] <= 1000){
						$data['pl'] = 1;
					}elseif($rs['pl'] > 1000 && $rs['pl'] <= 1600){
						$data['pl'] = 2;
					}elseif($rs['pl'] > 1600 && $rs['pl'] <= 2000){
						$data['pl'] = 3;
					}elseif($rs['pl'] > 2000 && $rs['pl'] <= 2500){
						$data['pl'] = 4;
					}elseif($rs['pl'] > 2500 && $rs['pl'] <= 3000){
						$data['pl'] = 5;
					}elseif($rs['pl'] > 3000 && $rs['pl'] <= 4000){
						$data['pl'] = 6;
					}else{
						$data['pl'] = 7;
					}
					json($data,1);
				}
			}
			$this->title = '浩磊车险';
			// 读取绑定的车辆信息
			$info = M('cars')->where(array('openid'=>$_SESSION['openid']))->find();
			$info['tel'] = M('member')->where(array('openid'=>$_SESSION['openid']))->getField('tel');
			$this->assign('info',$info); //默认绑定的车辆信息
			$this->display();
		}else{
			if(!$_SESSION['openid'] || !$_SESSION['InsuranceOrder']) json("请刷新页面重试!");
			$data = cookie('InsuranceOrder');
			if(!$data) json('请返回重新提交!');
			if(md5($data) != $_SESSION['InsuranceOrder']) json('数据效验有误，请重新提交!');
			$data = json_decode($data,true);
			$data['cphm'] = '豫A'.$data['cphm'];
			$data['openid'] = $_SESSION['openid'];
			$data['tbrname'] = I('tbrname');
			$data['tbrsfzh'] = I('tbrsfzh');
			$data['tbrtel'] = I('tbrtel');
			$data['a1'] = I('a1');
			$data['a2'] = I('a2');
			$data['a3'] = I('a3');
			$data['adr'] = I('adr');
			$data['lat'] = I('lat');
			$data['lng'] = I('lng');
			$data['cid'] = I('cid');
			$data['ps'] = I('ps');
			// 读取保险公司
			$com = M('insurance_company')->field('user,pwd',true)->where(array('id'=>$data['cid']))->find();
			// 验证用户是否是会员
			$isvip = M('member')->where(array('openid'=>$_SESSION['openid']))->getField('vip');
			if($isvip == 1){
				$zk = $com['zk2']; //会员使用专享折扣
			}else{
				$zk = $com['zk1'];
			}
			$data['price'] = round($data['total']*$zk,2); //计算优惠价
			$data['addtime'] = NOW_TIME;
			$data['status'] = 1; //待支付
			$data['paytime'] = '';
			$data['wxpayid'] = '';
			$data['orderid'] = md5($data['openid'].$data['total'].$data['price'].$data['addtime']);
			$id = M('insurance_orders')->add($data);
			if($id){
				// 清空COOKIE
				cookie('InsuranceOrder',null);
				unset($_SESSION['InsuranceOrder']);
				json(U('Insurance/orderpay',array('id'=>$id)),1);
			}else{
				json('订单创建失败，请稍后重试!');
			}
		}
	}

	#订单支付#
	public function orderpay(){
		header("Content-type: text/html; charset=utf-8");
		if(IS_GET){
			$this->IsUser(true);
			$this->title = '投保订单支付';
			$id = I('id');
			$info = M('insurance_orders')->where(array('id'=>$id,'status'=>1))->find();
			if(!$info) alert('该订单已支付或不存在！',U('Insurance/mine'));
			$info['com'] = M('insurance_company')->where(array('id'=>$info['cid']))->getField('name');
			$conf = $this->payconfig($info['orderid'],$info['price']*100,'保险订单支付',C('SITE_URL').'/api/inpay.php');
			if(!$conf || $conf['return_code'] == 'FAIL') exit("<script>alert('对不起，微信支付接口调用错误!".$conf['return_msg']."');history.go(-1);</script>");
			$this->orderid = $conf['prepay_id'];
			//生成页面调用参数
			$jsApiObj["appId"] = $conf['appid'];
			$timeStamp = NOW_TIME;
		    $jsApiObj["timeStamp"] = "$timeStamp";
		    $jsApiObj["nonceStr"] = $this->createNoncestr();
			$jsApiObj["package"] = "prepay_id=".$conf['prepay_id'];
		    $jsApiObj["signType"] = "MD5";
		    $jsApiObj["paySign"] = $this->MakeSign($jsApiObj);
		    $this->parameters = json_encode($jsApiObj);
			$this->assign('info',$info);
			$this->display();
		}else{
			// 更新订单
			if(!$_SESSION['openid']) json('请刷新页面重试!');
			$id = I('get.id');
			$info = M('insurance_orders')->where(array('id'=>$id,'openid'=>$_SESSION['openid'],'status'=>1))->find();
			if(!$info) json('您无权操作该订单!');
			$data = array();
			$data['lat'] = I('post.lat');
			$data['lng'] = I('post.lng');
			$data['ps'] = I('post.ps');
			// 读取保险公司
			$com = M('insurance_company')->field('user,pwd',true)->where(array('id'=>$info['cid']))->find();
			// 验证用户是否是会员
			$isvip = M('member')->where(array('openid'=>$_SESSION['openid']))->getField('vip');
			if($isvip == 1){
				$zk = $com['zk2']; //会员使用专享折扣
			}else{
				$zk = $com['zk1'];
			}
			$data['price'] = round($info['total']*$zk,2); //重新计算优惠价
			if($data['ps'] == 2) $data['price'] = $data['price']+10; //UU +10元
			$data['orderid'] = md5($info['openid'].$info['total'].$data['price'].NOW_TIME);
			$r = M('insurance_orders')->where(array('id'=>$info['id']))->save($data);
			if($r){
				json('订单成功更新!',1);
			}else{
				json('更新失败!');
			}
		}
	}


	#计算报价#
	public function pricing(){
		if(!$_SESSION['openid']) alert('请刷新重试！',U('Insurance/index'));
		$data = I('get.');
		$_GET['cphm'] = '豫A'.$data['cphm']; //补充显示
		// 计算交强险 $jqx
		$diff = $this->diffDate($data['register_date'],date('Y-m-d'));
		if($diff['year'] < 2 || ($diff['year'] > 1 && $data['es'] == 1)){
			$jqx = 950; //第一年
			if($data['limit'] == 2) $jqx = 1100; //6座以上
		}else if($diff['year'] == 2){
			$jqx = 855; //第二年
			if($data['limit'] == 2) $jqx = 990; //6座以上
		}else if($diff['year'] == 3){
			$jqx = 760; //第三年
			if($data['limit'] == 2) $jqx = 880; //6座以上
		}else if($diff['year'] > 3){
			$jqx = 665; //三年以上
			if($data['limit'] == 2) $jqx = 770; //6座以上
		}
		
		// 计算车船税
		if($data['pl'] == 1){
			$ccs = 180;
		}else if($data['pl'] == 2){
			$ccs = 300;
		}else if($data['pl'] == 3){
			$ccs = 420;
		}else if($data['pl'] == 4){
			$ccs = 720;
		}else if($data['pl'] == 5){
			$ccs = 1500;
		}else if($data['pl'] == 6){
			$ccs = 3000;
		}else if($data['pl'] == 7){
			$ccs = 4500;
		}
		$info['ccs'] = $ccs;
		// 三者险
		if($data['sanzhe'] == 5){
			$sanzhe = 703;
			if($data['limit'] == 2) $sanzhe = 652; //6座以上
		}else if($data['sanzhe'] == 10){
			$sanzhe = 1015;
			if($data['limit'] == 2) $sanzhe = 918; //6座以上
		}else if($data['sanzhe'] == 20){
			$sanzhe = 1258;
			if($data['limit'] == 2) $sanzhe = 1119; //6座以上
		}else if($data['sanzhe'] == 30){
			$sanzhe = 1421;
			if($data['limit'] == 2) $sanzhe = 1253; //6座以上
		}else if($data['sanzhe'] == 50){
			$sanzhe = 1705;
			if($data['limit'] == 2) $sanzhe = 1491; //6座以上
		}else if($data['sanzhe'] == 100){
			$sanzhe = 2220;
			if($data['limit'] == 2) $sanzhe = 1943; //6座以上
		}else if($data['sanzhe'] == 0){
			$sanzhe = 0;
		}
		$info['sanzhe'] = $sanzhe;
		// 计算不计免赔
		if($data['bjmp'] == 1){
			$bjmp = $sanzhe*0.15; //不计免赔
		}else{
			$bjmp = 0;
		}
		//浮动比率
		if($data['used'] == 1){
			$jqx = $jqx*1; //-10%
			$bjmp = $bjmp*1;
		}else if($data['used'] == 5){
			$jqx = $jqx*1.1; //+10%
			$bjmp = $bjmp*1.1;
		}else if($data['used'] == 6){
			$jqx = $jqx*1.3; //+30%
			$bjmp = $bjmp*1.3;
		}
		$info['jqx'] = $jqx;
		$info['bjmp'] = $bjmp;
		$info['total'] = $info['jqx']+$info['ccs']+$info['sanzhe']+$info['bjmp'];//总保费
		// 读取保险公司
		$com = M('insurance_company')->field('user,pwd',true)->where(array('status'=>1))->order('px desc')->select();
		// 验证用户是否是会员
		$isvip = M('member')->where(array('openid'=>$_SESSION['openid']))->getField('vip');
		$info['isvip'] = $isvip;
		for ($i=0; $i < count($com); $i++) { 
			if($isvip == 1){
				$zk = $com[$i]['zk2']; //会员使用专享折扣
			}else{
				$zk = $com[$i]['zk1'];
			}
			$com[$i]['price'] = round($info['total']*$zk,2); //计算优惠价
		}
		$this->assign('info',$info);
		$this->assign('com',$com);
		// 记录COOKIE
		$data['fee1'] = $info['jqx'];
		$data['fee2'] = $info['ccs'];
		$data['fee3'] = $info['sanzhe'];
		$data['fee4'] = $info['bjmp'];
		$data['total'] = $info['total'];
		$_SESSION['InsuranceOrder'] = md5(json_encode($data)); //加密用于保存数据时验证是否被修改
		cookie('InsuranceOrder',json_encode($data));
		$this->display();
	}

	/*
	*function：计算两个日期相隔多少年，多少月，多少天
	*param string $date1[格式如：2011-11-5]
	*param string $date2[格式如：2012-12-01]
	*return array array('年','月','日');
	*/
	protected function diffDate($date1,$date2){
		if(strtotime($date1)>strtotime($date2)){
			$tmp=$date2;
			$date2=$date1;
			$date1=$tmp;
		}
		list($Y1,$m1,$d1)=explode('-',$date1);
		list($Y2,$m2,$d2)=explode('-',$date2);
		$Y=$Y2-$Y1;
		$m=$m2-$m1;
		$d=$d2-$d1;
		if($d<0){
			$d+=(int)date('t',strtotime("-1 month $date2"));
			$m--;
		}
		if($m<0){
			$m+=12;
			$y--;
		}
		if($m > 0 || $d > 0) $Y++; //增加特殊处理
		return array('year'=>$Y,'month'=>$m,'day'=>$d);
	}

	#保存微信上传的图片 并进行识别#
	public function savewximg(){
		if(!$_SESSION['uid'] && !$_SESSION['openid']) json('请刷新重试!');
		$res = I('res'); //资源ID 
		$type = I('type'); //类型
		import("@.ORG.AccessToken");
        $weixin = new AccessToken();
        $url = 'http://file.api.weixin.qq.com/cgi-bin/media/get?access_token='.C('ACCESSTOKEN').'&media_id='.$res;
        $file = 'Public/uploads/images/wximgs/'.md5($_SESSION['openid'].$res).'.jpg';
        $r = file_put_contents($file,file_get_contents($url));
        if($r > 50){
        	// 识别图像
        	import("@.ORG.DataPlus.OCR");
			$ocr = new OCR();
        	if($type == 'sfz'){
        		// 身份证识别
        		$info = $ocr->ReadID($file);
        	}else{
        		// 行驶证识别
        		$info = $ocr->ReadXZ($file);
        		if($info['plate_num']){
        			$info['plate_num'] = mb_substr($info['plate_num'], 2,5,'utf8');
        		}
        		if($info['register_date']) $info['register_date'] = date('Y-m-d',strtotime($info['register_date']));
        	}
        	if($info['success'] == 1){
        		// 识别正常
        		$info['msg'] = $file;
        		json($info,1);
        	}else{
        		// 识别失败 删除图像
        		@unlink($file);
        		json('图像识别错误，请正确拍摄证件正面，确保文字清晰可见。');
        	}
        }else{
        	json('图片保存失败，请刷新重试!'.$res);
        }
	}


	#测试身份证识别接口#
	public function test(){
		
		//$r = $ocr->ReadID('1.jpg'); //识别身份证
		/*
		[address] => 河南省延津县胙城乡王堤村38号
	    [birth] => 19890715
	    [config_str] => {"side":"face"}
	    [name] => 贾召鹏
	    [nationality] => 汉
	    [num] => 410726198907155014
	    [request_id] => 20161018165205_468ce6163de52700158
	    [sex] => 男
	    [success] => 1
	    */

		//$r = $ocr->ReadJZ('2.jpg');

		/*
		Array
		(
		    [config_str] => 
		    [end_date] => 20260223
		    [name] => 刘净
		    [num] => 410305198810211522
		    [request_id] => 20161018180008_c241447ba4411a868
		    [start_date] => 20160223
		    [success] => 1
		    [vehicle_type] => C1
		)
		*/

		$r = $ocr->ReadXZ('3.jpg');

		/*
		Array
		(
		    [config_str] => 
		    [engine_num] => 3126624
		    [issue_date] => 
		    [model] => 马自达牌CAM7150A5
		    [owner] => 刘净
		    [plate_num] => 豫C656A1
		    [register_date] => 20150327
		    [request_id] => 20161018184558_1bb0d8f8e6d02cae647
		    [success] => 1
		    [vehicle_type] => 
		    [vin] => LVRHDFAL6EN339458
		)
		*/
		print_r($r);
	}

	#支付成功#
	public function paysuccess(){
		$this->title = '支付成功';
		$this->display();
	}

	#支付回调处理#
	public function callback(){
		$xml = file_get_contents("php://input");
		$log = json_decode(json_encode(simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NOCDATA)), true);
		$orderid = $log['out_trade_no']; //订单号
		$exist = M('wxpay_logs')->where(array('transaction_id'=>$log['transaction_id']))->find();
		if($exist){
			M('wxpay_logs')->where(array('id'=>$exist['id']))->save($log);
		}else{
			M('wxpay_logs')->add($log); //记录
		}
		$info = M('insurance_orders')->where(array('orderid'=>$orderid))->find();
		if($info['status'] > 1) exit("<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[OK]]></return_msg></xml>");
		$data['status'] = 2;
		$data['paytime'] = NOW_TIME;
		$data['wxpayid'] = $log['transaction_id'];
		// 更新订单状态
		$r = M('insurance_orders')->where(array('id'=>$info['id']))->save($data);
		if($r){
			// 成功
			exit("<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[OK]]></return_msg></xml>");
		}
	}

	#我的保单#
	public function mine(){
		$this->IsUser(true);
		$p = I('p');
		if(!$p) $p = 1;
		$this->title = '我的投保记录';
		$map = array();
		$map['openid'] = $_SESSION['openid'];
		$map['status'] = array('egt',0);
		$model = M('insurance_orders');
		import('@.ORG.Util.Page');// 导入分页类
		$list = $model->where($map)->order('addtime desc')->page($p.',20')->select();
		$this->assign('list',$list);// 赋值数据集
		$count	= $model->where($map)->count();// 查询满足要求的总记录数
		$page 	= new Page($count,20);// 实例化分页类 传入总记录数和每页显示的记录数
		$page->setConfig('theme','%upPage%  %linkPage%  %downPage%');
		$page->rollPage = 3 ;
		$show	= $page->show();// 分页显示输出
		$this->assign('page',$show);// 赋值分页输出
		//分页跳转的时候保证查询条件
		foreach($map as $key=>$val) {
			$page->parameter   .=   "$key=".urlencode($val).'&';
		}
		$this->display();
	}

	#保险公司管理后台#
	// public function login(){
	// 	if(IS_GET){
	// 		if($_SESSION['ins_adm']) U('Insurance/bdlist','','',true,true); //已登录自动跳转
	// 		if($_SESSION['ins_uid']) U('Insurance/orderlist','','',true,true); //已登录自动跳转
	// 		$this->title = '保险公司管理后台';
	// 		$this->display();
	// 	}else{
	// 		$user = I('user');
	// 		$pwd = I('pwd');
	// 		if($user == 'admin' && md5($pwd) == 'd26174a0b0e0ae8f6cd28fcc0fed1472'){
	// 			// 是管理员
	// 			$_SESSION['ins_adm'] = $user;
	// 			json('恭喜您登录成功!',1);
	// 		}
	// 		$info = M('insurance_company')->where(array('user'=>$user,'pwd'=>md5($pwd),'status'=>1))->find();
	// 		if($info){
	// 			$_SESSION['ins_uid'] = $info['id'];
	// 			json('恭喜您登陆成功!',1);
	// 		}else{
	// 			json('账号信息错误!');
	// 		}
	// 	}
	// }

	// #退出登录#
	// public function logout(){
	// 	unset($_SESSION['ins_uid']);
	// 	unset($_SESSION['ins_adm']);
	// 	U('Insurance/login','','',true,true);
	// }

	// #检查登录状态#
	// protected function IsLogin(){
	// 	if(!$_SESSION['ins_uid']){
	// 		unset($_SESSION['ins_adm']);
	// 		if(IS_AJAX) json("请刷新页面重新登录!");
	// 		alert("请登录帐号进行操作!",U('Insurance/login'));
	// 	}
	// }

	// #检查管理状态#
	// protected function IsAdm(){
	// 	if(!$_SESSION['ins_adm']){
	// 		unset($_SESSION['ins_uid']);
	// 		if(IS_AJAX) json("请刷新页面重新登录!");
	// 		alert("请登录帐号进行操作!",U('Insurance/login'));
	// 	}
	// }

	#订单列表#
	public function orderlist(){
		$this->IsLogin();
		if(IS_GET){
			$word = I('word');
			$stat = I('stat');
			$date = I('date');
			$this->eq = 0;
			$p = I('p');
			if(!$p) $p = 1;
			$this->title = '投保信息管理';
			$map = array();
			if($word) $map['tbrname|tbrtel|tbrsfzh|name|sfzh|adr|cphm'] = array('like','%'.$word.'%');
			if($date) $map['addtime'] = array('between',array(strtotime($date),strtotime($date)+86400));
			$map['cid'] = $_SESSION['ins_uid'];
			if($stat > 0){
				$map['status'] = $stat;
			}else{
				$map['status'] = array('in','3,0,6');
			}
			$model = M('insurance_orders');
			import('@.ORG.Util.Page');// 导入分页类
			$list = $model->where($map)->order('addtime desc')->page($p.',15')->select();
			$this->assign('list',$list);// 赋值数据集
			$count	= $model->where($map)->count();// 查询满足要求的总记录数
			$page 	= new Page($count,15);// 实例化分页类 传入总记录数和每页显示的记录数
			$page->setConfig('theme','%upPage%  %linkPage%  %downPage%');
			$page->rollPage = 3 ;
			$show	= $page->show();// 分页显示输出
			$this->assign('page',$show);// 赋值分页输出
			//分页跳转的时候保证查询条件
			foreach($map as $key=>$val) {
				$page->parameter   .=   "$key=".urlencode($val).'&';
			}
			$this->display();
		}else{

		}
	}

	#订单详情#
	public function orderinfo(){
		$this->IsLogin();
		if(IS_GET){
			$this->title = '投保详情';
			$this->eq = 0;
			$id = I('id');
			$map = array();
			$map['cid'] = $_SESSION['ins_uid'];
			$map['id'] = $id;
			$info = M('insurance_orders')->where($map)->find();
			if(!$info) alert("找不到相关订单信息!",U('Insurance/orderlist'));
			$this->assign('info',$info);
			$this->display();
		}else{
			$id = I('get.id');
			$ret = I('post.ret');
			$res = I('post.res');
			$map = array();
			$map['cid'] = $_SESSION['ins_uid'];
			$map['id'] = $id;
			$map['status'] = 3; //待处理状态
			$info = M('insurance_orders')->where($map)->find();
			if(!$info) json('无法操作该订单!');
			if($ret == 1){
				// 成功
				$data['baodan'] = $res;
				M('insurance_orders')->where(array('id'=>$info['id']))->save($data);
			}else{
				// 失败
				$this->CancelOrder($info['id'],$res);
			}
			json('处理成功!',1);
		}
	}

	#取消订单并退款#
	protected function CancelOrder($id,$res=''){
		$info = M('insurance_orders')->where(array('id'=>$id))->find();
		if(!$info) return false;
		if($info['wxpayid']){
			// 执行退款操作
			$r = $this->refund($info['wxpayid'],$info['orderid'],$info['price']*100);
			if($r['return_code'] == 'SUCCESS'){
				$data = array('status'=>0,'baodan'=>'','res'=>$res);
				$r = M('insurance_orders')->where(array('id'=>$id))->save($data);
			}else{
				return false;
			}
		}else{
			$data = array('status'=>0,'baodan'=>'','res'=>$res);
			$r = M('insurance_orders')->where(array('id'=>$id))->save($data);
		}
		return $r;
	}

	#绑定微信#
	public function bindwx(){
		$this->IsLogin();
		if(IS_GET){
			if(IS_AJAX){
				// 获取绑定二维码
				$ercode = 'Public/insurance/bd-'.md5($_SESSION['ins_uid'].'KXCUA').'.jpg';
				if(file_exists($ercode)){
					json($ercode,1);
				}else{
					// 没有就生成
					import("@.ORG.AccessToken");
					$AT = new AccessToken();
					$r = $AT->makecode('INSBD-'.$_SESSION['ins_uid']);
					if(is_array($r)){
						file_put_contents($ercode, file_get_contents($r['pic']));
						json($ercode,1);
					}else{
						json('二维码生成失败，请稍候再试!'.$r,1);
					}
				}
			}
			$this->title = '绑定微信';
			$this->eq = 2;
			$info = M('insurance_company')->field('user,pwd',true)->where(array('id'=>$_SESSION['ins_uid']))->find();
			$this->assign('info',$info);
			$this->display();
		}else{
			// 解除绑定
			$data = array();
			$data['openid'] = '';
			$data['nickname'] = '';
			$data['headimgurl'] = '';
			$r = M('insurance_company')->where(array('id'=>$_SESSION['ins_uid']))->save($data);
			json('解除成功!',1);
		}
	}

	#财务提现#
	public function moneylogs(){
		$this->IsLogin();
		if(IS_GET){
			$this->title = '财务提现';
			$this->eq = 1;
			$info = M('insurance_company')->field('user,pwd',true)->where(array('id'=>$_SESSION['ins_uid']))->find();
			$this->assign('info',$info);
			// 读取最近6条资金记录
			$list = M('insurance_moneylogs')->where(array('cid'=>$_SESSION['ins_uid']))->limit(6)->order('addtime desc')->select();
			$this->assign('list',$list);
			$this->display();
		}else{
			$money = I('money');
			if($money < 1){
				json('提现金额错误!');
			}else{
				$r = $this->DoMoney($_SESSION['ins_uid'],-$money,'财务提现');
				if($r === true){
					json('恭喜您已成功提现'.$money.'元至微信!',1);
				}else{
					json($r); //原因
				}
			}
		}
	}

	#保险公司资金处理#
	protected function DoMoney($cid,$fee,$event=''){
		$info = M('insurance_company')->field('user,pwd',true)->where(array('id'=>$cid))->find();
		if($fee < 0){
			// 提现
			$fee1 = abs($fee); //绝对值
			if($info['money'] < $fee1) return '账户余额不足!';
			if(!$info['openid']) return '尚未绑定微信，无法执行提现操作!';
			// 先执行付款操作
			$r = $this->payto($info['openid'],NOW_TIME.'-'.$cid,$fee1,$event);
			if($r['result_code'] == 'SUCCESS' && $r['return_code'] == 'SUCCESS'){
				// 扣除资金
				M('insurance_company')->where(array('id'=>$info['id']))->setDec('money',$fee1);
			}else{
				return $r['return_msg'];
			}
		}else{
			// 增加收入
			M('insurance_company')->where(array('id'=>$info['id']))->setInc('money',$fee);
			M('insurance_company')->where(array('id'=>$info['id']))->setInc('total',$fee);
		}
		// 记录资金日志
		$data = array();
		$data['cid'] = $info['id'];
		$data['fee'] = $fee;
		$data['event'] = $event;
		$data['now'] = M('insurance_company')->where(array('id'=>$info['id']))->getField('money');
		$data['addtime'] = NOW_TIME;
		$data['status'] = 1;
		M('insurance_moneylogs')->add($data);
		return true;
	}

	#管理员后台保单列表#
	public function bdlist(){
		$this->IsAdm();
		if(IS_GET){
			$word = I('word');
			$stat = I('stat');
			$date = I('date');
			$this->eq = 0;
			$p = I('p');
			if(!$p) $p = 1;
			$this->title = '投保订单管理';
			$map = array();
			if($word) $map['tbrname|tbrtel|tbrsfzh|name|sfzh|adr|cphm'] = array('like','%'.$word.'%');
			if($date) $map['addtime'] = array('between',array(strtotime($date),strtotime($date)+86400));
			if($stat != ''){
				$map['status'] = $stat;
			}else{
				$map['status'] = array('egt',0);
			}
			$model = M('insurance_orders');
			import('@.ORG.Util.Page');// 导入分页类
			$list = $model->where($map)->order('addtime desc')->page($p.',15')->select();
			for ($i=0; $i < count($list); $i++) { 
				$com = M('insurance_company')->where(array('id'=>$list[$i]['cid']))->field('cover,name')->find();
				$list[$i]['com'] = $com['name'];
				$list[$i]['cover'] = $com['cover'];
			}
			$this->assign('list',$list);// 赋值数据集
			$count	= $model->where($map)->count();// 查询满足要求的总记录数
			$page 	= new Page($count,15);// 实例化分页类 传入总记录数和每页显示的记录数
			$page->setConfig('theme','%upPage%  %linkPage%  %downPage%');
			$page->rollPage = 3 ;
			$show	= $page->show();// 分页显示输出
			$this->assign('page',$show);// 赋值分页输出
			//分页跳转的时候保证查询条件
			foreach($map as $key=>$val) {
				$page->parameter   .=   "$key=".urlencode($val).'&';
			}
			$this->display();
		}else{

		}
	}

	#资金明细#
	public function feelogs(){
		$this->IsAdm();
		if(IS_GET){
			$word = I('word');
			$date = I('date');
			$this->eq = 1;
			$p = I('p');
			if(!$p) $p = 1;
			$this->title = '资金明细';
			$map = array();
			if($word) $map['event'] = array('like','%'.$word.'%');
			if($date) $map['addtime'] = array('between',array(strtotime($date),strtotime($date)+86400));
			$model = M('insurance_moneylogs');
			import('@.ORG.Util.Page');// 导入分页类
			$list = $model->where($map)->order('addtime desc')->page($p.',10')->select();
			for ($i=0; $i < count($list); $i++) { 
				$com = M('insurance_company')->where(array('id'=>$list[$i]['cid']))->field('cover,name')->find();
				$list[$i]['name'] = $com['name'];
				$list[$i]['cover'] = $com['cover'];
			}
			$this->assign('list',$list);// 赋值数据集
			$count	= $model->where($map)->count();// 查询满足要求的总记录数
			$page 	= new Page($count,10);// 实例化分页类 传入总记录数和每页显示的记录数
			$page->setConfig('theme','%upPage%  %linkPage%  %downPage%');
			$page->rollPage = 3 ;
			$show	= $page->show();// 分页显示输出
			$this->assign('page',$show);// 赋值分页输出
			//分页跳转的时候保证查询条件
			foreach($map as $key=>$val) {
				$page->parameter   .=   "$key=".urlencode($val).'&';
			}
			$this->display();
		}else{

		}
	}

	#保险公司管理#
	public function company(){
		$this->IsAdm();
		if(IS_GET){
			$this->eq = 2;
			$p = I('p');
			if(!$p) $p = 1;
			$this->title = '保险公司';
			$map = array();
			$map['status'] = array('egt',0);
			$model = M('insurance_company');
			import('@.ORG.Util.Page');// 导入分页类
			$list = $model->where($map)->order('id desc')->page($p.',10')->select();
			$this->assign('list',$list);// 赋值数据集
			$count	= $model->where($map)->count();// 查询满足要求的总记录数
			$page 	= new Page($count,10);// 实例化分页类 传入总记录数和每页显示的记录数
			$page->setConfig('theme','%upPage%  %linkPage%  %downPage%');
			$page->rollPage = 3 ;
			$show	= $page->show();// 分页显示输出
			$this->assign('page',$show);// 赋值分页输出
			//分页跳转的时候保证查询条件
			foreach($map as $key=>$val) {
				$page->parameter   .=   "$key=".urlencode($val).'&';
			}
			$this->display();
		}else{

		}
	}

	#添加或编辑保险公司#
	public function addcom(){
		$this->IsAdm();
		if(IS_GET){
			$this->eq = 2;
			$this->title = '添加保险公司';
			$id = I('id');
			if(IS_AJAX){
				$t = I('t');
				if($t == -1){
					$r = M('insurance_company')->where(array('id'=>$id))->setField('status',-1);
					if($r){
						json('删除成功!',1);
					}else{
						json('删除失败!');
					}
				}
			}
			if($id > 0){
				$this->title = '编辑保险公司';
				$info = M('insurance_company')->where(array('id'=>$id))->find();
				$this->assign('info',$info);
			}
			$this->display();
		}else{
			$data = I('post.');
			if($data['id'] > 0){
				// 编辑
				$info = M('insurance_company')->where(array('id'=>$data['id']))->find();
				if($info['user'] != $data['user']){
					if(M('insurance_company')->where(array('user'=>$data['user']))->count() > 0) json('该帐号已存在!');
				}
				if($data['pwd'] == ''){
					unset($data['pwd']); //为空则不修改密码
				}else{
					$data['pwd'] = md5($data['pwd']); //新密码
				}
				$r = M('insurance_company')->where(array('id'=>$data['id']))->save($data);
				json('修改成功!',1);
			}else{
				// 新增
				if(M('insurance_company')->where(array('user'=>$data['user']))->count() > 0) json('该帐号已存在!');
				$data['addtime'] = NOW_TIME;
				$data['pwd'] = md5($data['pwd']);
				$r = M('insurance_company')->add($data);
				if($r) json('添加成功!',1);
			}
			json('内容无变化!');
		}
	}

	#取消UU跑腿#
	protected function CancelUU($id){
		$info = M('insurance_orders')->where(array('id'=>$id))->find();
		if($info['status'] == 2 || $info['status'] == 3){
			// 这两个状态才可执行该操作
			if($info['ps'] == 2 && $info['wxpayid']){
				// 执行退款操作 -10元
				$r = $this->refund($info['wxpayid'],$info['orderid'],10*100);
				if($r['return_code'] == 'SUCCESS'){
					// 更新订单信息
					$data = array();
					$data['price'] = $info['price']-10;
					$data['ps'] = 1;
					M('insurance_orders')->where(array('id'=>$info['id']))->save($data);
					return true;
				}
			}
		}
		return false;
	}


	#保单详情#
	public function bdinfo(){
		$this->IsAdm();
		if(IS_GET){
			$this->title = '投保详情';
			$this->eq = 0;
			$id = I('id');
			if(IS_AJAX){
				$ret = I('ret');
				if($ret == 1){
					// 取消UU跑腿
					$r = $this->CancelUU($id);
					if($r){
						json('切换成功!',1);
					}else{
						json('操作失败!');
					}
				}
			}
			$map = array();
			$map['id'] = $id;
			$info = M('insurance_orders')->where($map)->find();
			if(!$info) alert("找不到相关订单信息!",U('Insurance/bdlist'));
			$this->assign('info',$info);
			$this->display();
		}else{
			$id = I('get.id');
			$ret = I('post.ret');
			$res = I('post.res');
			$info = M('insurance_orders')->where(array('id'=>$id))->find();
			if(!$info) json('无法操作该订单!');
			if($ret == 3){
				// 通过
				M('insurance_orders')->where(array('id'=>$info['id']))->setField('status',3);
			}else if($ret == 6){
				// 完成
				if($info['baodan'] == '' || $info['status'] != 3) json('该订单状态不允许完成！');
				$r = M('insurance_orders')->where(array('id'=>$info['id']))->save(array('status'=>6,'donetime'=>NOW_TIME));
				if($r){
					$r = $this->DoMoney($info['cid'],$info['price'],'保单收入');
					if($r !== true){
						json($r); //失败原因
					}
				}else{
					json('操作失败!');
				}
			}else{
				// 失败
				$this->CancelOrder($info['id'],$res);
			}
			json('处理成功!',1);
		}
	}








/*

	////////////////保险公司后台管理//////////////////////////////

*/

	#保险公司管理#
	public function companylist(){
		$this->IsAdm(true);
		if(IS_GET){
			$this->title = '保险公司列表';
			$this->eq = '合作商家';
			$p = I('p',1);
			$id = I("id");
			$word = I('word');
			$map = array();
			if ($id) $map['id'] = $id;
			if($word) $map['nickame|adr'] = array('like','%'.$word.'%');
			$map['status'] = array('egt',0);
			$model = M('insurance_company');
			import('@.ORG.Util.Page');// 导入分页类
			$list = $model->where($map)->order('px desc,id desc')->page($p.',10')->select();
		
			$this->assign('list',$list);// 赋值数据集

			$count	= $model->where($map)->count();// 查询满足要求的总记录数
			$this->total = $count;
			$page 	= new Page($count,10);// 实例化分页类 传入总记录数和每页显示的记录数
			$page->setConfig('theme','%upPage%  %linkPage%  %downPage%');
			$page->rollPage = 5 ;
			$show	= $page->show();// 分页显示输出
			$this->assign('page',$show);// 赋值分页输出
			//分页跳转的时候保证查询条件
			foreach($map as $key=>$val) {
				$page->parameter   .=   "$key=".urlencode($val).'&';
			}
			$this->display();
		}else{
			$id = I('id');
			$t = I('t');
			$r = M('insurance_company')->where(array('id'=>$id))->setField('status',$t);
			json('操作成功!',1);
		}
	}

	#添加保险公司#
	public function addinsurance(){
		$this->IsAdm(true);
		if(IS_GET){
			$this->title = '添加/修改保险公司';
			$this->eq = '合作商家';
			$id = I('id');
			if($id > 0){
				$info = M('insurance_company')->where(array('id'=>$id))->find();
				$this->assign('info',$info);
			}
			$this->display();
		}else{
			$data = I('post.');

			if ($data['pwd'] == "") {
				unset($data['pwd']);
			}else{

				$data['pwd'] = md5($data['pwd']);
			}

			if($data['id'] > 0){
				$r = M('insurance_company')->where(array('id'=>$data['id']))->save($data);
			}else{
				// 新增
				$r = M('insurance_company')->add($data);
			}
			if($r){
				json("保存成功",1);
			}else{
				json("保存失败");
			}
		}
	}











}