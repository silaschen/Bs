<?php
return array (
  'AppId' => '',
  'AppSecret' => '',
  'MCHID' => '',
  'SIGNKEY' => '',
  'WXTOKEN' => '',
  'WX_MODEL' => '0',
  'WXOPEN_URL' => '',
  'BAKAPI' => '',
  'ACCESSTOKEN' => '',
  'EXPIREIN' => '',
  'ASTFROM' => '',
  'JSAPI_TICKET' => '',
  'JSAPI_EXPIRE' => '',
);
?>