<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta http-equiv="Cache-Control" content="no-cache" />
<title><?php echo ($title); ?></title>
<meta name="author" content="宾果智造">
<meta http-equiv="cleartype" content="on">
<meta content="telephone=no,email=no" name="format-detection">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=0">

<link href="Public/res/insurance/weui/weui.css" rel="stylesheet">
<script type="text/javascript">
document.write('<div id="loadingToast" class="weui_loading_toast"><div class="weui-mask_transparent"></div><div class="weui-toast"><i class="weui-loading weui-icon_toast"></i><p class="weui-toast__content">数据加载中</p></div></div>');
document.onreadystatechange = completeLoading;
function completeLoading() {
    if (document.readyState == "complete") {
        document.getElementById("loadingToast").style.display="none";
    }
}
</script>
<link rel="stylesheet" href="Public/res/insurance/app.css"/>
<script src="//cdn.bootcss.com/jquery/3.1.1/jquery.min.js"></script>
<script type="text/javascript" src="Public/res/insurance/common.js"></script>


<!-- 页面css js -->

</head>
<body ontouchstart>

<!-- 顶部 -->


<center><h1 class="page__title">管理后台</h1></center>
<div class="weui-cells__title">帐号</div>
<div class="weui-cells">
    <div class="weui-cell">
        <div class="weui-cell__bd">
            <input class="weui-input" type="text" name='user' placeholder="请输入登录帐号">
        </div>
    </div>
</div>
<div class="weui-cells__title">密码</div>
<div class="weui-cells">
    <div class="weui-cell">
        <div class="weui-cell__bd">
            <input class="weui-input" type="password" name='pwd' placeholder="请输入登录密码">
        </div>
    </div>
</div>
<div class="weui-btn-area">
    <a class="weui-btn weui-btn_primary" href="javascript:login();">登录</a>
</div>
<script type="text/javascript">
function login(){
  var user = vr('user');
  var pwd = vr('pwd');
  if(user == ''){
    alert('请输入账号!');
  }else if(pwd == ''){
    alert('请输入密码!');
  }else{
    loading("请稍后...");
    $.post(location.href,{"user":user,"pwd":pwd},function(data){
      alert(data.msg);
      if(data.ret == 1){
        location.reload();
      }else{
        loading('',0);
      }
    },'JSON')
  }
}
</script>


<!-- 底部 -->
<footer class="weui-footer">
    <!-- <p class="weui-footer__links">
        <a href="javascript:void(0);" class="weui-footer__link"></a>
    </p> -->
    <p class="weui-footer__text" onclick="location.href='http://binguo.me/wx';">©宾果智造</p>
    <p class="weui-footer__text" onclick="location.href='http://binguo.me/wx';">[值得信赖的互联网开发服务商] </p>
</footer>




<script src="//cdn.bootcss.com/fastclick/1.0.6/fastclick.min.js"></script>
<script type="text/javascript">
$(function() {
    FastClick.attach(document.body);
});
</script>
<!--[if lt IE 9]>
<script src="//cdn.bootcss.com/html5shiv/3.7.3/html5shiv.min.js"></script>
<script src="//cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->



</body>
</html>