<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title><?php echo ($title); ?></title>
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<link rel="stylesheet" href="Public/com/AdminLTE/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="//cdn.bootcss.com/font-awesome/4.5.0/css/font-awesome.min.css">
<link rel="stylesheet" href="//cdn.bootcss.com/ionicons/2.0.1/css/ionicons.min.css">
<link rel="stylesheet" href="Public/com/AdminLTE/css/AdminLTE.css">
<link rel="stylesheet" href="Public/com/AdminLTE/css/skins/skin-red.css">
<!-- jQuery 2.1.4 -->
<script src="//cdn.bootcss.com/jquery/2.2.1/jquery.min.js"></script>
<!-- Bootstrap 3.3.5 -->
<script src="Public/com/AdminLTE/bootstrap/js/bootstrap.min.js"></script>
<script src="Public/com/common.js"></script>
<style type="text/css">
/*loading*/
#mask{position: fixed;z-index: 999999;top: 0;bottom: 0;left: 0;right: 0;display: none;}
#mask .loading{padding: 10px 15px;background: #333;opacity: 0.75;text-align: center;color: #FFF;line-height: 23px;position: fixed;left:0;right: 0;bottom: 0;top: 0;width: 120px;height: 65px;z-index: 999999;margin: auto;border-radius: 4px;}
</style>
<!--[if lt IE 9]>
<script src="//cdn.bootcss.com/html5shiv/3.7.3/html5shiv.min.js"></script>
<script src="//cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>
<body class="hold-transition skin-red sidebar-mini">
<div class="wrapper">
  <!-- Main Header -->
<header class="main-header">

  <!-- Logo -->
  <a href="#" target='_blank' class="logo">
    <!-- mini logo for sidebar mini 50x50 pixels -->
    <span class="logo-mini"><i class='fa fa-television'></i></span>
    <!-- logo for regular state and mobile devices -->
    <span class="logo-lg"><i class='fa fa-television'></i> <?php echo APP_NAME;?></span>
  </a>

  <!-- Header Navbar -->
  <nav class="navbar navbar-static-top" role="navigation">
    <!-- Sidebar toggle button-->
    <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
      <span class="sr-only">Toggle navigation</span>
    </a>
    <!-- Navbar Right Menu -->
    <div class="navbar-custom-menu">
      <ul class="nav navbar-nav">
        <!-- User Account Menu -->
        <li class="dropdown user user-menu">
          <!-- Menu Toggle Button -->
          <a href="#" class="dropdown-toggle" data-toggle="dropdown">
            <!-- The user image in the navbar-->
            <img src="Public/res/admin.png" class="user-image" alt="User Image">
            <!-- hidden-xs hides the username on small devices so only the image appears. -->
            <span class="hidden-xs"><?php echo $_SESSION['sys_user'];?></span>
          </a>
          <ul class="dropdown-menu">
            <!-- The user image in the menu -->
            <li class="user-header">
              <img src="Public/res/admin.png" class="img-circle" alt="User Image">
              <p>
                <?php echo $_SESSION['sys_user'];?>
                <small>上次登录：<?php echo cookie('lastlogin');?></small>
              </p>
            </li>
      
            <!-- Menu Footer-->
            <li class="user-footer">
              <div class="pull-left">
                <a href="<?php echo U('Sys/profile');?>" class="btn btn-default btn-flat">修改密码</a>
              </div>
              <div class="pull-right">
                <a href="<?php echo U('Sys/logout');?>" onclick="return confirm('确定退出登录？');" class="btn btn-default btn-flat">退出系统</a>
              </div>
            </li>
          </ul>
        </li>
      </ul>
    </div>
  </nav>
</header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
  <section class="sidebar">
    <ul class="sidebar-menu">
      <li><a href="<?php echo U('Sys/index');?>"><i class="fa fa-bar-chart"></i> <span>管理概况</span></a></li>

      <li class="treeview">
      <a href="#"><i class="fa fa-clone"></i> <span>会员管理</span><i class="fa fa-angle-left pull-right"></i></a>
      <ul class="treeview-menu">
          <li><a href="<?php echo U('User/userlist');?>">会员列表</a></li>
          <li><a href="<?php echo U('Illegal/illegallist');?>">车辆列表</a></li>
        </ul>
      </li>

        <li class="treeview">
      <a href="#"><i class="fa fa-clone"></i> <span>店铺管理</span><i class="fa fa-angle-left pull-right"></i></a>
      <ul class="treeview-menu">
          <li><a href="<?php echo U('Shop/shoplist');?>">电铺列表</a></li>
          <li><a href="<?php echo U('Sys/artcategory');?>">xxx</a></li>
        </ul>
      </li>

         <li class="treeview">
      <a href="#"><i class="fa fa-clone"></i> <span>商品管理</span><i class="fa fa-angle-left pull-right"></i></a>
      <ul class="treeview-menu">
          <li><a href="<?php echo U('Product/plist');?>">商品列表</a></li>
          <li><a href="<?php echo U('Product/catelist');?>">商品分类</a></li>

          <li><a href="<?php echo U('Product/catelist');?>">卡券管理</a></li>
        </ul>
      </li>

           <li class="treeview">
      <a href="#"><i class="fa fa-clone"></i> <span>订单管理</span><i class="fa fa-angle-left pull-right"></i></a>
      <ul class="treeview-menu">
          <li><a href="<?php echo U('User/userlist');?>">服务订单</a></li>
          <li><a href="<?php echo U('Order/illegallist');?>">违章订单</a></li>

          <li><a href="<?php echo U('Sys/artcategory');?>">店铺资金</a></li>
        </ul>
      </li>

          <li class="treeview">
      <a href="#"><i class="fa fa-clone"></i> <span>合作商家</span><i class="fa fa-angle-left pull-right"></i></a>
      <ul class="treeview-menu">
          <li><a href="<?php echo U('Check/checklist');?>">检测站</a></li>
          <li><a href="<?php echo U('Insurance/companylist');?>">保险公司</a></li>

        </ul>
      </li>



      <li class="treeview">
      <a href="#"><i class="fa fa-clone"></i> <span>文章管理</span><i class="fa fa-angle-left pull-right"></i></a>
      <ul class="treeview-menu">
          <li><a href="<?php echo U('Sys/artlist');?>">文章列表</a></li>
          <li><a href="<?php echo U('Sys/artcategory');?>">分类管理</a></li>
        </ul>
      </li>
      <li class="treeview">
        <a href="#"><i class="fa fa-cog"></i> <span>系统设置</span> <i class="fa fa-angle-left pull-right"></i></a>
        <ul class="treeview-menu">
          <li><a href="<?php echo U('Mate/text');?>">微信素材</a></li>
          <li><a href="<?php echo U('Cmd/text');?>">回复规则</a></li>
          <li><a href="<?php echo U('ModMenu/edit');?>">微信菜单</a></li>
          <li><a href="<?php echo U('Sys/site');?>">站点设置</a></li>
          <li><a href="<?php echo U('Sys/advs');?>">轮播广告</a></li>
          <li><a href="<?php echo U('Sys/vendor');?>">微信配置</a></li>
          <li><a href="<?php echo U('Sys/group');?>">权限控制</a></li>
          <li><a href="<?php echo U('Sys/admin');?>">系统管理员</a></li>
        </ul>
      </li>
    </ul><!-- /.sidebar-menu -->
  </section>
  <!-- /.sidebar -->
</aside>
<?php if($eq >= '0' OR $eq != ''): ?><script type="text/javascript">
if(!isNaN('<?php echo ($eq); ?>')){
  $(".sidebar-menu > li").eq(<?php echo ($eq); ?>).addClass('active');
}else{
  $(".sidebar-menu > li").each(function(){
    var txt = $.trim($(this).children('a').text());
    if(txt == '<?php echo ($eq); ?>'){
      $(this).addClass('active');
      return;
    }
  });
}
</script><?php endif; ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    
    <!-- Main content -->
    <section class="content">
    
  <div class="box box-solid">
    <div class="box-header with-border">
      <h3 class="box-title">用户列表  共:<?php echo ($total); ?></h3>
    </div><!-- /.box-header -->
    <div class="box-body">
      <form method="GET" action="<?php echo U('User/userlist');?>" id='search' style="margin-bottom:15px;">
      <div class="row">
      

        <div class="col-xs-8 col-md-6">
          <div class="input-group">
            <input name="word" type='text' class='form-control' value="<?php echo I('word');?>" placeholder='帐号/ID/昵称/姓名/电话 关键词搜索..'>
            <span class="input-group-addon" onclick="$('#search').submit();"><i class="fa fa-search"></i></span>
            <?php if($_GET['stat'] > '0' OR $_GET['word'] != '' OR $_GET['sid'] != ''): ?><a title='清除条件' class="input-group-addon" href="<?php echo U('User/userlist');?>"><i class="fa fa-remove"></i></a><?php endif; ?>
          </div>
        </div>
      </div>
      </form>
      <table class="table table-bordered">
        <thead>
          <th>ID</th>
          <th>头像</th>
          <th width='100'>昵称</th>
          <th>性别</th>
          <th>电话</th>
          <th>绑定车辆</th>
          <th>注册时间</th>
          <th>状态</th>
          <th>操作</th>
        </thead>
        <tbody>
      <?php if(is_array($list)): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><tr>
          <td><?php echo ($vo["id"]); ?></td>
          <td><img src='<?php echo ($vo["headimgurl"]); ?>' class='img-rounded' height='35'></td>
         
          <td><?php if($vo["shop"] > '0'): ?><a href="<?php echo U('SysShop/shoplist',array('id'=>$vo['shop']));?>"><?php echo ($vo["nickname"]); ?></a><?php else: echo ($vo["nickname"]); endif; ?></td>
          <td><?php if($vo["sex"] == '1'): ?><small class="badge bg-blue">男</small><?php elseif($vo["sex"] == '2'): ?><small class="badge bg-danger">女</small><?php else: ?><small class="badge bg-gray">-</small><?php endif; ?></td>
          <td><?php if($vo["tel"] != ''): echo ($vo["tel"]); else: ?>暂无<?php endif; ?></td>
       
   
          <td>5</td>
         
          <td><?php echo (date('Y-m-d H:i:s',$vo["addtime"])); ?></td>
          <td><?php if($vo["status"] == '1'): ?><span class="label label-success">正常</span><?php else: ?><span class="label label-danger">冻结</span><?php endif; ?></td>

          <td>
              <div class="btn-group">
                <button type="button" class="btn btn-default dropdown-toggle btn-xs" data-toggle="dropdown">
                  管理
                  <span class="caret"></span>
                  <span class="sr-only">+</span>
                </button>
                <ul class="dropdown-menu" role="menu">
                  <li><a href="javascript:detail(<?php echo ($vo['id']); ?>)">查看详情</a></li>
               
                </ul>
              </div>
            </td>
         
        </tr><?php endforeach; endif; else: echo "" ;endif; ?>
        </tbody>
      </table>
    </div><!-- /.box-body -->
    <div class="box-footer clearfix">
      <ul class="pagination pagination-sm no-margin pull-left"><?php echo ($page); ?></ul>
    </div>  
  </div>
<!-- 查看详情 -->
<div class="modal" id='detail'>
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
        <h4 class="modal-title">会员详情</h4>
      </div>
      <div class="modal-body">
        <table class="table table-bordered" id='showuser'>
          
        </table>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default pull-left" data-dismiss="modal">关闭</button>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div>
<script type="text/javascript">
function detail(id){
  loading2('读取中..');
  $.get(location.href,{"id":id},function(data){
    if(data.sex == 1){
      data.sex = '男';
    }else if(data.sex == 2){
      data.sex = '女';
    }else{
      data.sex = '未知';
    }
  
     var str = "<tbody><tr><td>姓名：</td><td>"+data.name+"</td><td>电话：</td><td colspan='3'>"+data.tel+"</td></tr><tr><td>昵称：</td><td>"+data.nickname+"</td><td>性别：</td><td>"+data.sex+"</td><td>语言：</td><td>"+data.language+"</td></tr><tr><td>国家：</td><td>"+data.country+"</td><td>省份：</td><td>"+data.province+"</td><td>城市：</td><td>"+data.city+"</td></tr><tr><td>注册：</td><td colspan='4'>"+unix_to_datetime(data.addtime)+"</td></tr><tr><td colspan='2'>OPENID：</td><td colspan='2'>"+data.openid+"</td></tr></tbody>";
    $("#showuser").html(str);
    loading2('',0);
    $("#detail").modal('show');
  },'JSON');
}


function setstat(id,t){
  if(t == -1){
    var r = confirm("确定删除该会员？");
  }else if(t == 1){
    var r = confirm("确定启用该会员？");
  }else if(t == 0){
    var r = confirm("确定禁用该会员？");
  }
  if(r == true){
    $.post(location.href,{"id":id,"t":t},function(data){
      alert(data.msg);
      if(data.ret == 1) location.reload();
    },'JSON');
  }
}
</script>


    </section><!-- /.content -->
  </div><!-- /.content-wrapper -->
  <!-- Main Footer -->
  <footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">值得信赖的移动互联网开发服务商!</div>
    <!-- Default to the left -->
    <a href="http://binguo.me/wx/" target='_blank'>&copy; 宾果智造</a>
  </footer>
</div><!-- ./wrapper -->
<!-- AdminLTE App -->
<script src="Public/com/AdminLTE/js/app.min.js"></script>

<script type="text/javascript">
  
  function getarea(f,t,m){
  if(m == undefined) m = false;
  var id = $("select[name='"+f+"']").val();
  if(id == 0 || id == undefined){
    $("select[name='"+t+"']").html("<option value='0'>全部地区</option>").show();
    return;
  }
  $.ajax({
    url:"<?php echo U('Common/location');?>",
    data:{"id":id},
    type:"GET",
    dataType:"JSON",
    async:false,
    success:function(data){
      if(data){
        if(m){
          var str = "<option value='0'>全部地区</option>";
        }else{
          var str = '';
        }
        for (var i = 0; i < data.length; i++) {
          str += "<option value='"+data[i].id+"'>"+data[i].name+"</option>";
        };
        $("select[name='"+t+"']").html(str).show();
        if(f == 'a1') getarea('a2','a3',m);
      }else{
        $("select[name='"+t+"']").html('');
      }
    }
  });
}

  
</script>
<div id="mask"><div class='loading'></div></div>
</body>
</html>