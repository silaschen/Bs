<?php
/**
	##用户相关
**/
class UserAction extends CommonAction{
	#个人中心#
	public function index(){
		$this->IsUser(true);
		if(IS_GET){
			$this->title = '个人中心';
			$this->eq = '个人中心';
			$info = M('user_list')->where(array('id'=>$_SESSION['uid']))->find();
			$this->assign('info',$info);
			$this->display();
		}else{
			
		}
	}



/**
	////////////////////////////////////////////////////////////////后台部分
**/
	#用户管理#
	#会员列表#

	public function userlist(){

		$this->IsAdm(true);

		if(IS_GET){

			if(IS_AJAX){

				$id = I('id');

				$info = M('user_list')->where(array('id'=>$id))->find();

				exit(json_encode($info));

			}

			$this->title = '会员列表';

			$this->eq = "会员管理";
			$p = I('p');
			$word = I('word');
			$stat = I('stat');
			$id = I('id');
			if(!$p) $p = 1;
			$map = array();
			if($word) $map['nickname|id|name|tel'] = array('like','%'.$word.'%');
			$map['status'] = array('egt',0);
			if($id) $map['id'] = $id;
			if($stat == 1){

				$map['verify'] = 1;

			}else if($stat == 2){

				$map['shop'] = array('gt',0);

			}

			$model = M('user_list');

			import('@.ORG.Util.Page');// 导入分页类

			$list = $model->where($map)->order('addtime desc')->page($p.',10')->select();

			$this->assign('list',$list);// 赋值数据集

			$count	= $model->where($map)->count();// 查询满足要求的总记录数

			$this->total = $count;

			$page 	= new Page($count,10);// 实例化分页类 传入总记录数和每页显示的记录数

			//$page->setConfig('theme','%upPage%  %linkPage%  %downPage%');

			$page->rollPage = 5 ;

			$show	= $page->show();// 分页显示输出

			$this->assign('page',$show);// 赋值分页输出

			//分页跳转的时候保证查询条件

			foreach($map as $key=>$val) {

				$page->parameter   .=   "$key=".urlencode($val).'&';

			}

			$this->display();

		}else{

			$id = I('id');

			$t = I('t');

			$frz = I('frz');

			if($frz == 1){

				// 积分冻结操作

				$r = M('user_list')->where(array('id'=>$id))->setField('frz',$t);

				syslogs('会员积分冻结状态:'.$id['id'].'设为'.$t,$_SESSION['sys_uid']);

			}else{

				$r = M('user_list')->where(array('id'=>$id))->setField('status',$t);

				syslogs('会员状态:'.$id['id'].'设为'.$t,$_SESSION['sys_uid']);

			}

			json('操作成功!',1);

		}

	}







}