<?php 
/**
	##店铺管理
	##by binguo 

**/
class ShopAction extends CommonAction
{
	
	




	/*
		###############################后台###########################

	*/
	public function shoplist(){
		$this->IsAdm(true);
		if(IS_GET){
			$this->title = '店铺列表';
			$this->eq = '店铺管理';
			$p = I('p',1);
			$id = I("id");
			$word = I('word');
			$a1 = I("a1");
			$a2 = I("a2");
			$a3 = I("a3");
			$map = array();
			if ($id) $map['id'] = $id;
			if($word) $map['name'] = array('like','%'.$word.'%');

			if ($a1 > 0) $map['a1'] = $a1;
			if ($a2 > 0) $map['a2'] = $a2;
			if ($a3 > 0) $map['a3'] = $a3;

			$map['status'] = array('egt',0);
			$model = M('shop_list');
			import('@.ORG.Util.Page');// 导入分页类
			$list = $model->where($map)->order('id desc')->page($p.',10')->select();
		
			$this->assign('list',$list);// 赋值数据集

			$count	= $model->where($map)->count();// 查询满足要求的总记录数
			$this->total = $count;
			$page 	= new Page($count,10);// 实例化分页类 传入总记录数和每页显示的记录数
			$page->setConfig('theme','%upPage%  %linkPage%  %downPage%');
			$page->rollPage = 5 ;
			$show	= $page->show();// 分页显示输出
			$this->assign('page',$show);// 赋值分页输出
			//分页跳转的时候保证查询条件
			foreach($map as $key=>$val) {
				$page->parameter   .=   "$key=".urlencode($val).'&';
			}
			$this->display();
		}else{
			$id = I('id');
			$t = I('t');
			$r = M('shop_list')->where(array('id'=>$id))->setField('status',$t);
			json('操作成功!',1);
		}
	}

	#添加修改店铺#
	public function addshop(){
		$this->IsAdm(true);
		if(IS_GET){
			$this->title = '添加/修改店铺';
			$this->eq = '店铺管理';
			$id = I('id');
			if($id > 0){
				$info = M('shop_list')->where(array('id'=>$id))->find();
				$this->assign('info',$info);
			}
			//get the cates
			// $cates = M("shop_cates")->order("id desc")->select();
			// $this->assign("cates",$cates);
			$this->display();
		}else{
			$data = I('post.');

			if ($data['pwd'] == "") {
				unset($data['pwd']);
			}else{

				$data['pwd'] = md5($data['pwd']);
			}

			if($data['id'] > 0){
				$r = M('shop_list')->where(array('id'=>$data['id']))->save($data);
			}else{
				// 新增
				$data['addtime'] = NOW_TIME;
				$r = M('shop_list')->add($data);
			}
			if($r){
				json("保存成功",1);
			}else{
				json("保存失败");
			}
		}
	}

}
	




 ?>