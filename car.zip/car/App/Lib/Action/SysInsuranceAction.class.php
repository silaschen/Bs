<?php 
/**
#	#保险公司
**/
/**
* 
*/
class SysInsuranceAction extends CommonAction
{
	#保险公司管理#
	public function insurancelist(){
		$this->IsAdm(true);
		if(IS_GET){
			$this->title = '保险公司列表';
			$this->eq = '合作商家';
			$p = I('p',1);
			$id = I("id");
			$word = I('word');
			$map = array();
			if ($id) $map['id'] = $id;
			if($word) $map['nickame|adr'] = array('like','%'.$word.'%');
			$map['status'] = array('egt',0);
			$model = M('insurance_company');
			import('@.ORG.Util.Page');// 导入分页类
			$list = $model->where($map)->order('id desc')->page($p.',10')->select();
		
			$this->assign('list',$list);// 赋值数据集

			$count	= $model->where($map)->count();// 查询满足要求的总记录数
			$this->total = $count;
			$page 	= new Page($count,10);// 实例化分页类 传入总记录数和每页显示的记录数
			$page->setConfig('theme','%upPage%  %linkPage%  %downPage%');
			$page->rollPage = 5 ;
			$show	= $page->show();// 分页显示输出
			$this->assign('page',$show);// 赋值分页输出
			//分页跳转的时候保证查询条件
			foreach($map as $key=>$val) {
				$page->parameter   .=   "$key=".urlencode($val).'&';
			}
			$this->display();
		}else{
			$id = I('id');
			$t = I('t');
			$r = M('insurance_company')->where(array('id'=>$id))->setField('status',$t);
			json('操作成功!',1);
		}
	}

	#添加保险公司#
	public function addinsurance(){
		$this->IsAdm(true);
		if(IS_GET){
			$this->title = '添加/修改保险公司';
			$this->eq = '合作商家';
			$id = I('id');
			if($id > 0){
				$info = M('insurance_company')->where(array('id'=>$id))->find();
				$this->assign('info',$info);
			}
			$this->display();
		}else{
			$data = I('post.');

			if ($data['pwd'] == "") {
				unset($data['pwd']);
			}else{

				$data['pwd'] = md5($data['pwd']);
			}

			if($data['id'] > 0){
				$r = M('insurance_company')->where(array('id'=>$data['id']))->save($data);
			}else{
				// 新增
				$r = M('insurance_company')->add($data);
			}
			if($r){
				json("保存成功",1);
			}else{
				json("保存失败");
			}
		}
	}

	






}













 ?>