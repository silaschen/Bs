<?php
class WxAction extends TplAction{
	private function checkSignature(){
		$token = C('WXTOKEN');
		$signature = $_GET["signature"];
		$timestamp = $_GET["timestamp"];
		$nonce = $_GET["nonce"];
		$tmpArr = array($token, $timestamp, $nonce);
		sort($tmpArr, SORT_STRING);
		$tmpStr = implode( $tmpArr );
		$tmpStr = sha1( $tmpStr );
		if( $tmpStr == $signature ){
			return true;
		}else{
			return false;
		}
	}


	//处理主入口
	public function index(){
		if(!$this->checkSignature()) exit;
		$postStr = file_get_contents("php://input");
		$postObj = simplexml_load_string($postStr, 'SimpleXMLElement', LIBXML_NOCDATA);
		$this->fu = (string)$postObj->FromUserName;
		$this->tu = (string)$postObj->ToUserName;
		$MsgType = (string)$postObj->MsgType;
		if($MsgType == '') exit($_GET["echostr"]); //执行验证接口
		//根据消息类型进入相应操作
		switch($MsgType){
			case 'text':
		 	$content = strtolower(trim($postObj->Content)); //转为小写字母
			$this->find($MsgType,$content);
		  break;
		  case 'image':
		  	$picurl = (string)$postObj->PicUrl;
		  	$this->find($MsgType,$picurl);
		  break;
		  case 'location':
		  	$data = array();
		  	$data['px'] = $postObj->Location_X;
		  	$data['py'] = $postObj->Location_Y;
		  	$data['Label'] = $postObj->Label;
		  	$data['Scale'] = $postObj->Scale;
		  	$this->find($MsgType,$data);
		  break;
		  case 'event':
		  	$event = (string)$postObj->Event;
			$eventKey = (string)$postObj->EventKey;
			if($event == 'subscribe'){
				$this->ScanQR($postObj);
				$eventKey = '';
			}elseif($event == 'unsubscribe'){
				$eventKey = '';
			}elseif($event == 'CLICK'){
				
			}elseif($event == 'SCAN'){
				// 扫码推广二维码
				$this->ScanQR($postObj);
			}elseif($event == 'LOCATION'){

			}
			$x = (string)$postObj->Latitude; //纬度
			$y = (string)$postObj->Longitude; //经度
			$l = (string)$postObj->Precision; //精度
			if($x && $y){	//上报位置
			}
			$data = array();
		  	$data['event'] = $event;
		  	$data['value'] = $eventKey;
		  	$this->find($MsgType,$data);
		  break;
		  case 'voice':
		  	$word = (string)$postObj->Recognition; //语音识别结果
		  	$this->find('text',$word);
		  break;
		}
	}

	#自定义参数二维码扫描处理 传入消息体完整对象#
	protected function ScanQR($postObj){
		$eventKey = (string)$postObj->EventKey;
		$arr = explode('-', str_replace('qrscene_','', $eventKey));
		if($arr[0] && $arr[1] && strpos($arr[0], '/') > 0){
			// 参数格式正确 跨模块执行相应操作
			R($arr[0],array($postObj));
		}else if($ck[0] == 'SR' && $ck[1]){
			// 推广下线二维码
			$this->UserQR($ck[1],$this->fu);
		}
		return false;
	}

	#用户推广二维码#
	protected function UserQR($pid,$openid=''){
		if(!$openid && $this->fu) $openid = $this->fu; //默认当前请求用户openid
		$info = M('user_list')->where(array('id'=>$pid))->find(); //二维码主人
		if(!$info) return false;
		// 检查扫描者资料是否存在
		$user = M('user_list')->where(array('openid'=>$openid))->find();
		if(!$user){
			// 获取用户资料 并保存
            $data = $this->WxProfile($openid);
            if(!$data){
            	// 读取资料失败
            	return false;
            }
            $data['pid'] = $pid; //推荐人
            $data['openid'] = $openid;
			$data['addtime'] = NOW_TIME;
			$uid = M('user_list')->add($data);
			return $uid;
		}
	}

	#微信支付通知#
	public function PayCallBack(){
		$xml = file_get_contents("php://input");
        import("@.ORG.WeiXin");
        $WX = new WeiXin();
        $log = $WX->FromXml($xml);
        // 安全效验
        if(!$WX->CheckSign($log))  exit('Fail');
        // 检查有无重复通知
        $notified = M('wxpay_logs')->where(array('transaction_id'=>$log['transaction_id'],'result_code'=>'SUCCESS'))->count();
		if($notified > 0){
			// 已通知过的
			exit("<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[OK]]></return_msg></xml>");
		}
		M('wxpay_logs')->add($log); //记录
        if($log['attach'] == 'OD'){
        	//根据标识执行不同业务处理
        }else if($log['attach'] == 'CG'){
        	//exit("<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[OK]]></return_msg></xml>");
        }

	}


}