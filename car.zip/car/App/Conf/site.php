<?php
return array (
  'SITE_NAME' => '郑州汽车人',
  'SITE_LOGO' => 'Public/res/logo.png',
  'SITE_QRPIC' => '',
  'SITE_TEL' => '0371-88884224',
  'SITE_ADR' => '河南省郑州市5',
  'SITE_EMAIL' => 'mail@binguo.me',
);
?>