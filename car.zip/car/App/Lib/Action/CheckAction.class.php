<?php
/**
	## 预约审车
	## Yanglin 2017.3.1
**/
class CheckAction extends CommonAction{
	#主界面#
	public function index(){
		$this->IsUser(true);
		$this->title = '预约审车';
		$this->eq = '汽车服务';
		// 读取检测站
		$stat = M('check_station')->where(array('status'=>1))->order('px desc,id desc')->select();
		$this->assign('stat',$stat);
		// 读取上次预约
		$last = M('check_order')->where(array('openid'=>$_SESSION['openid']))->order("addtime desc")->find();
		$this->assign('last',$last);
		$this->display();
	}













	/**
	## //////////////////////////////////////////////////////////////////////监测站管理后台
	
**/

	#检测站管理#
	public function checklist(){
		$this->IsAdm(true);
		if(IS_GET){
			$this->title = '检测站列表';
			$this->eq = '合作商家';
			$p = I('p',1);
			$id = I("id");
			$word = I('word');
			$map = array();
			if ($id) $map['id'] = $id;
			if($word) $map['name|address'] = array('like','%'.$word.'%');
			$map['status'] = array('egt',0);
			$model = M('check_station');
			import('@.ORG.Util.Page');// 导入分页类
			$list = $model->where($map)->order('px desc,id desc')->page($p.',10')->select();
		
			$this->assign('list',$list);// 赋值数据集

			$count	= $model->where($map)->count();// 查询满足要求的总记录数
			$this->total = $count;
			$page 	= new Page($count,10);// 实例化分页类 传入总记录数和每页显示的记录数
			$page->setConfig('theme','%upPage%  %linkPage%  %downPage%');
			$page->rollPage = 5 ;
			$show	= $page->show();// 分页显示输出
			$this->assign('page',$show);// 赋值分页输出
			//分页跳转的时候保证查询条件
			foreach($map as $key=>$val) {
				$page->parameter   .=   "$key=".urlencode($val).'&';
			}
			$this->display();
		}else{
			$id = I('id');
			$t = I('t');
			$r = M('check_station')->where(array('id'=>$id))->setField('status',$t);
			json('操作成功!',1);
		}
	}

	#添加检测站#
	public function addstation(){
		$this->IsAdm(true);
		if(IS_GET){
			$this->title = '添加检测站';
			$this->eq = '合作商家';
			$id = I('id');
			if($id > 0){
				$info = M('check_station')->where(array('id'=>$id))->find();
				$this->assign('info',$info);
			}
			$this->display();
		}else{
			$data = I('post.');

			if ($data['pwd'] == "") {
				unset($data['pwd']);
			}else{

				$data['pwd'] = md5($data['pwd']);
			}

			if($data['id'] > 0){
				$r = M('check_station')->where(array('id'=>$data['id']))->save($data);
			}else{
				// 新增
				// $data['addtime'] = NOW_TIME;
				$r = M('check_station')->add($data);
			}
			if($r){
				json("保存成功",1);
			}else{
				json("保存失败");
			}
		}
	}





}